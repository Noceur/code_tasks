$(document).ready(function() {
    function validation(){
        return false;
    }

    $('.updateButton').on('click', function() {
        preventDefault();
        req = $.ajax({
            url : '/asd',
            type : 'GET',
            success : function(response){
                value = response;
                //modal.find('.modal-title').text('New message to ' + value);
            }
        });
        //console.log("test");

        req.done(function() {
            console.log(value['borka']);

            //$('#')
            //$('#memberSection'+member_id).fadeOut(1000).fadeIn(1000);
            //$('#memberNumber'+member_id).text(data.member_num);
            //console.log("test");

        });


    });
    $('.check-user').keyup(function(){
        var username = $(this).val();

        req = $.ajax({
            url : '/asd?username='+username,
            type : 'GET',
            data: $('form').serialize(),
            success : function(response){
                return response;
                //value = response;
                //if (value == false){
                //    console.log("taken");
                //}
                ////console.log(value['borka']);
                //console.log(value);
                ////modal.find('.modal-title').text('New message to ' + value);
            }
            /*error : function(err){
                console.log(err);
            }*/
        });
    });

});